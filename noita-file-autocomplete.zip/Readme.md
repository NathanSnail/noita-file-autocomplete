# Noita File Autocomplete

Features: 
* Vscode can complete Noita file paths
* Ctrl+Click to see path definitions
* Grab the current Noita file path via the command palette
* Invalid paths are detected as errors
* `dofile` and `dofile_once` now have support for provided functions and globals

## You must configure the paths to be correct for you!
